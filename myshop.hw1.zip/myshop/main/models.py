from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return self.name


def crate_starter_products():
    Product.objects.create(name='apple', price=50.0)
    Product.objects.create(name='orange', price=90.0)
    Product.objects.create(name='nuts', price=150.0)
    Product.objects.create(name='lemon', price=110.0)
    Product.objects.create(name='Mango', price=200.0)
    Product.objects.create(name='Blueberry', price=60.0)
    Product.objects.create(name='Dragon fruit', price=150.0)
    Product.objects.create(name='Pomegranate', price=180.0)